import React from "react";

const Navbar = () => {
  return (
    <>
      <nav class="nav flex flex-wrap items-center justify-between px-4 border-b">
        <div class="flex flex-no-shrink items-center mr-6 py-3 text-grey-darkest">
          {/* search bar */}
          {/* class="text-gray-600 h-4 w-4 fill-current" */}
          <div class="max-w-md mx-auto">
            <div class="relative flex items-center w-full h-12 rounded-lg bg-gray-100 overflow-hidden">
              <div class="grid place-items-center h-full w-12 text-gray-300">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  class="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>

              <input
                class="peer h-full w-full outline-none text-sm bg-gray-100 text-gray-700 pr-2"
                type="text"
                id="search"
                placeholder="Search"
              />
            </div>
          </div>
          {/* <div class=" justify-between sm:ml-6 sm:block">
            <div class="w-full">
              <input
                type="search"
                class="w-full px-4 py-2 bg-gray-100 text-gray-800 rounded-full focus:outline-none"
                placeholder= "&#128269 search"
                x-model="search"
              />
            </div>
          </div> */}
          {/* search bar */}
        </div>

        <input class="menu-btn hidden" type="checkbox" id="menu-btn" />
        <label
          class="menu-icon block cursor-pointer md:hidden px-2 py-4 relative select-none"
          for="menu-btn"
        >
          <span class="navicon bg-grey-darkest flex items-center relative"></span>
        </label>

        <ul class="menu border-b md:border-none flex justify-end list-reset m-0 w-full md:w-auto">
          <li class="border-t md:border-none">
            <a
              href="/"
              class="block md:inline-block px-4 py-3 no-underline text-grey-darkest hover:text-grey-darker font-bold"
            >
              <img
                class="h-8 w-8 rounded-full"
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                alt=""
              />
            </a>
          </li>

          <li class="border-t md:border-none">
            <a
              href="/about/"
              class="block md:inline-block px-4 py-3 no-underline text-grey-darkest hover:text-grey-darker"
            >
              Imrul kayes
            </a>
          </li>
        </ul>
      </nav>
    </>
  );
};

export default Navbar;
