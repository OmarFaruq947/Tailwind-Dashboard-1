import React from "react";
import analytics from "../assets/analytics-01.svg";
import logo from "../assets/csvlogo.svg";
import dashboard from "../assets/dashboard-square-01.svg";
import setting from "../assets/setting-02.svg";
import multiUser from "../assets/user-multiple.svg";
import payment from "../assets/wallet-02.svg";
import Navbar from "./Navbar";


const Dashboard = () => {
  return (
    <>
      <div className="relative min-h-screen md:flex " data-dev-hint="container">
        <input type="checkbox" id="menu-open" className="hidden" />
        <label
          htmlFor="menu-open"
          className="absolute right-2 bottom-2 shadow-lg rounded-full p-2 bg-gray-100 text-gray-600 md:hidden"
          data-dev-hint="floating action button"
        >
          <svg
            className="h-6 w-6"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </label>
        <header
          className="bg-gray-600 text-gray-100 flex justify-between md:hidden "
          data-dev-hint="mobile menu bar"
        >
          <a
            href="#"
            className="block p-4 text-white font-bold whitespace-nowrap truncate"
          >
            <img className="h-10" src={logo} alt="" />
          </a>
          <label
            htmlFor="menu-open"
            id="mobile-menu-button"
            className="m-2 p-2 focus:outline-none  hover:bg-[#F5F5F5] rounded-md"
          >
            <svg
              id="menu-open-icon"
              className="h-6 w-6 transition duration-200 ease-in-out"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
            <svg
              id="menu-close-icon"
              className="h-6 w-6 transition duration-200 ease-in-out"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </label>
        </header>


        <aside
          id="sidebar"
          className="bg-white border-r text-gray-900 md:w-[240px]  space-y-6 pt-6 px-0 absolute inset-y-0 left-0 transform md:relative md:translate-x-0 transition duration-200 ease-in-out  md:flex md:flex-col  overflow-y-auto z-50 w-full"
          data-dev-hint="sidebar; px-0 for frameless; px-2 for visually inset the navigation"
        >
          <div className="flex items-center flex-col mt-6">
            <a href="/" className="top-8">
              <img className="w-[64px] h-[68px]" src={logo} alt="" />
            </a>
          </div>

          <div className="px-4 ">
          <p className="text-[#8E8E8E] w-[92px] h-[17px] left-8 top-[140px] uppercase tracking-tighter text-[14px] font-bold">Admin user</p>
          </div>

          <nav className="items-start gap-y-4 flex flex-col" data-dev-hint="main navigation ">
            <a
              href="#"
              className="flex items-center space-x-2 w-full py-2 px-4 transition duration-200 hover:bg-[#F5F5F5] font-bold text-[#181818]"
            >
                <img src={dashboard} alt="" />
              <span>Dashboard</span>
            </a>


            <a
              href="#"
              className="flex items-center space-x-2 py-2 px-4 transition duration-200 hover:bg-[#F5F5F5] font-bold text-[#181818] w-full"
            >
                <img src={multiUser} alt="" />
              <span>Student Info</span>
            </a>

            <a
              href="#"
              className="flex items-center space-x-2 py-2 px-4 transition duration-200 hover:bg-[#F5F5F5] font-bold text-[#181818] w-full"
            >
              
              <img src={analytics} alt="" />
              <span>Analytics</span>
            </a>

            <a
              href="#"
              className="flex items-center space-x-2 py-2 px-4 transition duration-200 hover:bg-[#F5F5F5] font-bold text-[#181818] w-full"
            >
                <img src={payment} alt="" />
              <span>Payment Status</span>
            </a>

            <a
              href="#"
              className="flex items-center space-x-2 py-2 px-4 transition duration-200 hover:bg-[#F5F5F5] font-bold text-[#181818] w-full"
            >
            <img src={setting} alt="" />
              <span>Settings</span>
            </a>

          </nav>

        </aside>

        <main id="content" className="flex-1">
          <Navbar />

          <div className="max-w-7xl mx-auto">
            {/* Replace with your content */}
            <p>njnjk</p>
            {/* /End replace */}
          </div>
        </main>
      </div>
    </>
  );
};

export default Dashboard;
