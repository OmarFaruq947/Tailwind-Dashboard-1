import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <p>ErrorPage</p>
        </div>
    );
};

export default ErrorPage;