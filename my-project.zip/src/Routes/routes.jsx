import { createBrowserRouter } from "react-router-dom";
import Main from "../Layout/Main";
import Dashboard from "../Pages/Dashboard";
import ErrorPage from "../Pages/ErrorPage";

export const router = createBrowserRouter([
    {path:"/",
    element:<Main />,
    errorElement:<ErrorPage />,
    children:[
        {
            path:"/",
            element:<Dashboard />
        },
    ]
}
])